package za.ac.tut.evo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvoApplicationTests {

	@Test
	void contextLoads() {
	}

}
